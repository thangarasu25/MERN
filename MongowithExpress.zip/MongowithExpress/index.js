


const express = require('express');
const path = require('path');
const cors = require('cors');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const morgan = require('morgan');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const router = require('./routes/router.js');
const app = express();
const productsRouter = require('./routes/cartsroutes');

//Just I Set The moongo db connection
var db = mongoose.connection; 




mongoose.connect('mongodb://localhost:27017/com', {useNewUrlParser: true});
var conn = mongoose.connection;
conn.on('connected', function() {
    console.log('database is connected successfully');
});

app.use('/products', productsRouter);
// mongoose.connect('mongodb://localhost:27017/com').
//   catch(error => handleError(error));

//   mongoose.connection.on('error', err => {
//     logError(err);
//   });

// MongoClient.connect("mongodb://localhost:27017", function(err, db) {
//   if(!err) {
//     console.log("We are connected");
//   }
//   else{
//     console.log("error")
//   }
// });
// app.use(bodyParser.urlencoded({ extended: true }))

// app.use(bodyParser.json())

// app.get('/', (req, res) => {
//     res.json({"message": "Hello Crud Node Express"});
// });

// app.listen(3000, () => {
//     console.log("Server is listening on port 3000");
// });


const PORT = process.env.PORT || 8000;


app.use(cors());
app.use(express.json()); // parses data posted on any request and store it as an object under req.body

app.use(morgan('combined'));


app.all('*', (req, res) => {
  res.status(404).json({
    message: 'Not found',
  })
})

app.listen(PORT, () => {
  console.log(`Server Started. Listening on port ${PORT}`);  
})

