const appRouter = (app, fs) => { };

const userRoutes = (app, fs) => {
    app.get('/users', (req, res) => {
   res.send({"name":"Working Routing"});
    });
};




module.exports = { appRouter, userRoutes };