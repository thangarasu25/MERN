const cartRouter = require('express').Router();
const {
  getCartItems,
  deleteCart,
  addToCart,
  updateCartItem,
  removeItemFromCart
} = require('./../controller/cartcontroller');

cartRouter
  .get('/', getCartItems)
  .post('/', addToCart)
  .delete('/', deleteCart)
  .put('/:productId', updateCartItem)
  .delete('/:productId', removeItemFromCart);

module.exports = cartRouter;